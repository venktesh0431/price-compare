import React from "react";
import {BrowserRouter, Routes,Route} from "react-router-dom";
import Header from './common/Header';
import Footer from './common/Footer';
import Home from './pages/Home';
import About from './pages/About';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header/>
          <Routes>
            <Route path="/" element={<Home/>} exact />
            <Route path="/about" element={<About/>} exact />
          </Routes>
        <Footer/> 
        </BrowserRouter>    
    </div>
  );
}

export default App;
